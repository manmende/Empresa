public class Main {

    public static void main(String[] args) {

        //numericos

            //enteros
        byte variable1 = 5;
        short variable2 = 10;
        int variable3 = 30;
        long variable4 =100;
             //decimales
        float variable5 = 5.5f;
        double variable6 = 10.5;

        //booleanos
        boolean variable7 = false;
        boolean variable8 = true;

        //texto
        char variable9 = 'a';
        String variable10 = "Hola me llamo Andres";

        System.out.println(variable10);


    }
   }